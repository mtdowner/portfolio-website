# Simple Portfolio

Module 4 of the [Programming Hero](https://github.com/ProgrammingHero1/simple-portfolio/) app on [iOS](https://play.google.com/store/apps/details?id=com.learnprogramming.codecamp) takes you through making a basic, yet nice-looking portfolio. This repo contains my finished portfolio from this module.
